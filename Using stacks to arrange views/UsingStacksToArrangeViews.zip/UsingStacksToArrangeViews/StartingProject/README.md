# Using Stacks to Arrange Views

## Starting Project

Use this project to code along with [Using Stacks to Arrange Views](https://developer.apple.com/tutorials/app-dev-training/using-stacks-to-arrange-views).